export enum UserRole {
  SYSTEMADMIN = 'System admin',
  INSTRUCTOR = 'Instructor',
  STUDENT = 'Student',
}
